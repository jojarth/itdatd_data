import { defineCollection, reference } from "astro:content";
import { glob } from "astro/loaders";
import { z } from "astro/zod";
import { docsLoader } from "@astrojs/starlight/loaders";
import { docsSchema } from "@astrojs/starlight/schema";

const data = defineCollection({
  schema: z.object({
    datatype: z.literal("spell"),
    title: z.string(),
    reverseTitle: z.string().optional(),
    reverseShortDescription: z.string().optional(),
    reverseCasting: z.string().optional(),
    reverseRange: z.string().optional(),
    reverseDuration: z.string().optional(),
    counters: z.array(z.string()).optional(),
    dispels: z.array(z.string()).optional(),
    reverseCounters: z.array(z.string()).optional(),
    reverseDispels: z.array(z.string()).optional(),
    level: z.number(),
    school: z.string().optional(),
    casting: z.string(),
    range: z.string().optional(),
    duration: z.string().optional(),
    classes: z.array(z.string()).optional(),
    shortDescription: z.string().optional(),
    excerpt: z.string().optional(),
  }),
  loader: glob({
    pattern: "src/content/data/spelldata/spell_list/**/[^_]*.{md,mdx}",
  }),
});

const preserveMdxId = ({ entry }: { entry: string }) =>
  entry.replace(/\.mdx?$/, "");

const weaponFeatures = defineCollection({
  schema: z.object({
    datatype: z.literal("weapon_feature"),
    title: z.string(),
    shortDescription: z.string(),
  }),
  loader: glob({
    base: "./src/content/data/weapondata/weapon_features",
    pattern: "**/*.mdx",
    generateId: preserveMdxId,
  }),
});

const weaponProperties = defineCollection({
  schema: z.object({
    datatype: z.literal("weapon_property"),
    title: z.string(),
    shortDescription: z.string(),
  }),
  loader: glob({
    base: "./src/content/data/weapondata/weapon_properties",
    pattern: "**/*.mdx",
    generateId: preserveMdxId,
  }),
});

const weapons = defineCollection({
  schema: z.object({
    datatype: z.literal("weapon"),
    title: z.string(),
    group: z.string(),
    cost: z.string(),
    ep: z.union([z.number(), z.string()]),
    damage: z.string(),
    speed: z.number(),
    range: z.string(),
    properties: z.array(reference("weaponProperties")),
    proficient: z.array(reference("weaponFeatures")),
    skilled: z.array(reference("weaponFeatures")),
    expert: z.array(reference("weaponFeatures")),
    master: z.array(reference("weaponFeatures")),
    grandmaster: z.array(reference("weaponFeatures")),
    crossTrainedFrom: z.array(z.object({
      type: z.enum(["group", "exotic"]),
      name: z.string(),
    })).optional(),
    crossTrainsWith: z.array(z.object({
      type: z.enum(["group", "exotic"]),
      name: z.string(),
    })).optional(),
  }),
  loader: glob({
    base: "./src/content/data/weapondata/weapon_list",
    pattern: "**/*.mdx",
    generateId: preserveMdxId,
  }),
});

const armors = defineCollection({
  schema: z.object({
    datatype: z.literal("armor"),
    title: z.string(),
    type: z.enum(["None", "Light", "Medium", "Heavy", "Plate"]),
    grade: z.enum(["Fitted", "Munition"]).optional(),
    ac: z.number(),
    epEquipped: z.union([z.number(), z.string()]),
    epPacked: z.union([z.number(), z.string()]),
    cost: z.string(),
  }),
  loader: glob({
    base: "./src/content/data/armordata/armorlist",
    pattern: "**/*.mdx",
    generateId: preserveMdxId,
  }),
});

const encumbranceSchema = z.discriminatedUnion("type", [
  z.object({
    type: z.literal("fixed"),
    value: z.number(),
  }),
  z.object({
    type: z.literal("bundle"),
    quantity: z.number().int().positive(),
  }),
  z.object({
    type: z.literal("states"),
    values: z.record(z.string(), z.union([z.number(), z.string()])),
  }),
  z.object({
    type: z.literal("assumed"),
  }),
]);

const shields = defineCollection({
  schema: z.object({
    datatype: z.literal("shield"),
    title: z.string(),
    category: z.enum(["Buckler", "Small Shield", "Medium Shield", "Body Shield"]),
    material: z.enum(["Wood", "Reinforced", "Metal"]),
    cost: z.string(),
    encumbrance: encumbranceSchema,
    acBonus: z.number(),
    blockValue: z.number(),
    breakDie: z.string(),
    breakChance: z.number(),
    checkPenalty: z.number(),
  }),
  loader: glob({
    base: "./src/content/data/shielddata/shield_list",
    pattern: "**/*.mdx",
    generateId: preserveMdxId,
  }),
});

const items = defineCollection({
  schema: z.object({
    datatype: z.literal("item"),
    title: z.string(),
    category: z.enum([
      "Ammunition",
      "Containers",
      "Exploration Gear",
      "Food and Drink",
      "Light Sources",
      "Religious Gear",
      "Spellcasting Gear",
      "Tools",
      "Restraints",
      "Mount and Transport Gear",
      "Miscellaneous",
    ]),
    cost: z.string(),
    encumbrance: encumbranceSchema,
    consumable: z.boolean().optional(),
    notes: z.string().optional(),
    sortOrder: z.number().optional(),
  }),
  loader: glob({
    base: "./src/content/data/itemdata/item_list",
    pattern: "**/*.mdx",
    generateId: preserveMdxId,
  }),
});

const keywordFeatures = defineCollection({
  schema: z.object({
    datatype: z.literal("keyword_feature"),
    title: z.string(),
    shortDescription: z.string(),
    keywords: z.array(z.string()).min(1),
    otherPrerequisites: z.string().optional(),
  }),
  loader: glob({
    base: "./src/content/data/keywordfeaturedata/keyword_features",
    pattern: "**/*.mdx",
    generateId: preserveMdxId,
  }),
});

// How multiple instances of a condition combines.
const stackingSchema = z
  .enum(["highest", "stacks", "exclusive"])
  .optional();

const conditions = defineCollection({
  schema: z.object({
    datatype: z.literal("condition"),
    title: z.string(),
    shortDescription: z.string(),
    // Whether the condition takes a value, such as Exhausted (3).
    valued: z.boolean().default(false),
    stacking: stackingSchema,
    // Positive conditions help you; negative conditions harm you.
    polarity: z.enum(["positive", "negative"]),
    // Whether this condition imposes a rest penalty (see Rest and Recovery).
    impairsRest: z.boolean().default(false),
    tags: z.array(z.string()).optional(),
  }),
  loader: glob({
    base: "./src/content/data/conditiondata",
    pattern: "**/*.mdx",
    generateId: preserveMdxId,
  }),
});

const downtimeEvents = defineCollection({
  schema: z.object({
    datatype: z.literal("downtime_event"),
    title: z.string(),
    shortDescription: z.string(),
    // How long the event takes, e.g. "1 Downtime Week".
    time: z.string(),
    requirements: z.string().optional(),
    tags: z.array(z.string()).optional(),
  }),
  loader: glob({
    base: "./src/content/data/downtimedata",
    pattern: "**/*.mdx",
    generateId: preserveMdxId,
  }),
});

const afflictions = defineCollection({
  schema: z.object({
    datatype: z.literal("affliction"),
    title: z.string(),
    shortDescription: z.string(),
    // Poisons and diseases move up and down by saves; curses never regress.
    type: z.enum(["poison", "disease", "curse"]),
    save: z.enum(["Doom", "Device", "Binding", "Breath", "Spell"]),
    // Penalty to the exposure save only, for a potent dose (e.g. 2 means -2).
    exposurePenalty: z.number().optional(),
    // Virulent: roll every stage save twice; both must succeed.
    virulent: z.boolean().default(false),
    // How the affliction is caught, e.g. ["Injury", "Ingested"].
    exposure: z.array(z.string()),
    onset: z.string(),
    maxDuration: z.string().optional(),
    // How the affliction can be ended besides its stages (mainly curses).
    remedy: z.string().optional(),
    tags: z.array(z.string()).optional(),
  }),
  loader: glob({
    base: "./src/content/data/afflictiondata",
    pattern: "**/*.mdx",
    generateId: preserveMdxId,
  }),
});

const injuries = defineCollection({
  schema: z.object({
    datatype: z.literal("injury"),
    title: z.string(),
    shortDescription: z.string(),
    // How much the injury lowers maximum Hit Points until it heals.
    maxHitPointReduction: z.number(),
    // How many points the injury's Mending Track needs before it heals.
    mending: z.number(),
    // What treatment the injury needs before it begins to mend, if any.
    treatment: z.string().optional(),
    tags: z.array(z.string()).optional(),
  }),
  loader: glob({
    base: "./src/content/data/injurydata/injuries",
    pattern: "**/*.mdx",
    generateId: preserveMdxId,
  }),
});

const injuryTables = defineCollection({
  schema: z.object({
    datatype: z.literal("injury_table"),
    title: z.string(),
    // Which kinds of damage roll on this table.
    appliesTo: z.string(),
    tags: z.array(z.string()).optional(),
    rows: z.array(z.object({
      roll: z.number().int().min(1).max(12),
      // The id of an injury in injurydata/injuries. Leave out while undecided.
      injury: z.string().optional(),
    })),
  }),
  loader: glob({
    base: "./src/content/data/injurydata/tables",
    pattern: "**/*.mdx",
    generateId: preserveMdxId,
  }),
});

export const collections = {
  docs: defineCollection({
    loader: docsLoader(),
    schema: docsSchema({
      extend: z.object({
        spellcasting: z.object({
          type: z.enum(["Clerical", "Magical"]),
          method: z.enum(["Free-Hand", "Devotional"]),
        }).optional(),
        classSummary: z.object({
          role: z.string(),
          armor: z.string(),
        }).optional(),
      }),
    }),
  }),
  data,
  weaponFeatures,
  weaponProperties,
  weapons,
  armors,
  shields,
  items,
  keywordFeatures,
  conditions,
  afflictions,
  downtimeEvents,
  injuries,
  injuryTables,
};
